// Fill out your copyright notice in the Description page of Project Settings.


#include "PawnData.h"

UPawnData::UPawnData(const FObjectInitializer& ObjectInitializer)
{
	PawnClass = nullptr;
	InputConfig = nullptr;
}
